﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatrolBehaviour : AIBehaviour
{


    public override void Execute()
    {
        Debug.Log("Patrolling!");
    }
}
