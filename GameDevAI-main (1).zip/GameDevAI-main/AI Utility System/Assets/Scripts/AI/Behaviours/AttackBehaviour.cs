﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackBehaviour : AIBehaviour
{
    public override void Execute()
    {
        Debug.Log("Attack behaviour!");
    }
}
