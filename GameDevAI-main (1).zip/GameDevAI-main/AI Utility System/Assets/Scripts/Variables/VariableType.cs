﻿public enum VariableType
{

    Health = 0,
    Distance = 1

}